zshctl[version]="0.0.3"
zshctl[release_date]=1757037934
