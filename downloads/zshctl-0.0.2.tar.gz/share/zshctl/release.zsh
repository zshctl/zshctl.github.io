zshctl[version]="0.0.2"
zshctl[release_date]=1748626056
