zshctl[version]="0.0.6"
zshctl[release_date]=1764609299
