zshctl[version]="0.0.4"
zshctl[release_date]=1759996901
