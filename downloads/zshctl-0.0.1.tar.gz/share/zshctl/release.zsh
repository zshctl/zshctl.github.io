zshctl[version]="0.0.1"
zshctl[release_date]=1747276838
