zshctl[version]="0.0.5"
zshctl[release_date]=1764180554
