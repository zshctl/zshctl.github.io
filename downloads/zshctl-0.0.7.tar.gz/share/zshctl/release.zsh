zshctl[version]="0.0.7"
zshctl[release_date]=1784172084
